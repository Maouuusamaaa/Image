# Revision v8 — Neutral Stance and Proportion Correction

## Why this revision exists
Review of the supplied 20-second render showed that the ordinary guard pose was already wrong: both hands rose above the shoulder line, elbows formed antenna-like peaks, and the fighters stood too far apart for the rig's arm lengths to reach the intended targets naturally.

## Changes
- Brought the fighters into a closer, deliberate range (base positions x=443 and x=517).
- Repositioned the lead wrist to the cheek/shoulder line and the rear wrist to the upper chest.
- Reversed the elbow bend direction so the elbows resolve downward instead of upward.
- Recalibrated arm segment lengths to 38 + 38 pixels, matched to the new spacing.
- Kept contact frames target-locked and retained post-contact reaction timing.
- Added visual QA outputs and posture-specific regression tests.

## Important limitation
The rig remains procedural 2D line art. These corrections target the obvious neutral-pose failure and reach mismatch; they do not establish motion-capture fidelity or prove that every frame is artistically natural.

## QA outcome
- Automated regression tests: 3 passed.
- Render: 1,200 frames, 60 FPS, 960×540, 20 seconds.
- `output/contact-sheet.png` includes neutral standing, approach, strike, and recovery samples.
- `output/qa-report.json` records render metadata and remaining limitations.
