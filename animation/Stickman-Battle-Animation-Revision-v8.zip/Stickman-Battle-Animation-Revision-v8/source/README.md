# Character source

Characters are procedural models in `scripts/render_battle.py`, not separate raster cutouts. Both share the same joint layout and proportions; accent colors distinguish the cyan and amber fighters. Pose definitions are deterministic and interpolated from named choreography beats.
