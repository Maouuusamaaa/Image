# Stickman Battle Animation — Revision v7

Revision v7 directly addresses the visible failures in the supplied v6 render: attacks that stopped short of the opponent and hit indicators that could appear without verified contact.

## Changes
- Eleven authored strikes each have a wind-up, a defined contact frame, retraction, and recovery.
- At the exact contact timestamp, the striking wrist is placed on the target surface; the contact marker appears only after wrist-to-target distance is verified.
- Targets are chosen on the near side of the opponent's head or upper torso.
- Defender recoil begins after the contact timestamp, rather than in anticipation.
- Stance spacing and arm reach are configured so all authored target points are physically reachable by the simple two-segment arm rig.
- Guard wrist positions were moved closer to a usable defensive position.
- White background, black stick figures, and one continuous ground line are retained.

## Render
- 960 × 540
- 60 FPS
- 20 seconds / 1,200 frames
- H.264 MP4

## Validation
Run from this folder:
`python -m unittest discover -s tests -v`

The tests verify all 11 authored strikes have a reachable target and zero wrist-to-target distance at the impact timestamp. Three automated tests pass. This verifies scripted contact geometry, not artistic perfection.

## Remaining visual issues
The fight is still a procedural stick-figure rig. Elbow silhouettes, close body spacing, weight transfer, and foot articulation need further animation-focused refinement. The current result should not be described as fully natural yet.

## Render again
`python scripts/render_battle.py --output output/stickman-battle-scene-01.mp4`

This is original procedural 2D choreography, not motion capture and not an exact reproduction of any reference video.
