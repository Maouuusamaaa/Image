#!/usr/bin/env python3
"""Revision v7: target-locked stick-fight choreography.
Every authored strike has wind-up, contact, recoil and recovery phases.
At the contact frame the wrist is solved to the target surface before impact response begins.
"""
import argparse, math, shutil, subprocess
from pathlib import Path
from PIL import Image, ImageDraw

W,H,FPS,DURATION,GROUND=960,540,60,20,424
INK=(12,12,12); BG=(255,255,255)

def clamp(v,a=0.,b=1.): return max(a,min(b,v))
def smooth(t):
    t=clamp(t); return t*t*(3-2*t)
def mix(a,b,t): return a+(b-a)*t
def dist(a,b): return math.hypot(b[0]-a[0],b[1]-a[1])
def unit(a,b):
    d=dist(a,b) or 1
    return ((b[0]-a[0])/d,(b[1]-a[1])/d)
def toward(a,b,amount):
    u=unit(a,b); return (a[0]+u[0]*amount,a[1]+u[1]*amount)
def ik2(root,target,l1,l2,bend=1):
    dx,dy=target[0]-root[0],target[1]-root[1]
    d=max(abs(l1-l2)+1e-3,min(math.hypot(dx,dy),l1+l2-1e-3))
    ux,uy=dx/d,dy/d
    along=(l1*l1-l2*l2+d*d)/(2*d)
    h=math.sqrt(max(0,l1*l1-along*along))
    return (root[0]+along*ux-bend*h*uy,root[1]+along*uy+bend*h*ux)
def pulse(t,c,w):
    q=(t-c)/w
    return math.exp(-q*q) if abs(q)<3.5 else 0

# time, attacker, strike kind, wind-up, contact, retract-end, defender recoil direction
EVENTS=[
 (2.25,0,'head',2.00,2.25,2.52,1),
 (3.35,1,'body',3.08,3.35,3.64,-1),
 (5.15,0,'body',4.88,5.15,5.45,1),
 (6.45,1,'head',6.16,6.45,6.75,-1),
 (8.15,0,'head',7.87,8.15,8.48,1),
 (9.55,1,'body',9.28,9.55,9.85,-1),
 (11.35,0,'body',11.06,11.35,11.66,1),
 (12.72,1,'head',12.43,12.72,13.02,-1),
 (14.55,0,'head',14.25,14.55,14.88,1),
 (16.05,1,'body',15.78,16.05,16.35,-1),
 (17.75,0,'body',17.47,17.75,18.05,1),
]
def fighter_state(t,side):
    # Deliberate stance width, low center of gravity, and modest idle motion.
    xbase=436 if side==0 else 524
    facing=1 if side==0 else -1
    # step into range before the first exchange, then settle instead of skating.
    approach=smooth((t-.25)/1.45)
    x=xbase + (3*facing*approach)
    bob=1.1*math.sin(t*2.6+side*.7)
    lean=2.0*math.sin(t*1.9+side*1.4)
    crouch=2+1.2*math.sin(t*2.2+side)
    recoil=0.0
    for tm,att,kind,wind,hit,retract,away in EVENTS:
        if side==att:
            # attacker rotates into the strike, then naturally brings shoulders back.
            windup=smooth((t-wind)/max(.001,hit-wind))
            recovery=smooth((t-hit)/max(.001,retract-hit))
            active=1 if t>=hit else windup
            if wind <= t <= hit:
                lean += facing*(2+8*windup)
                crouch += 2*(1-windup)
            elif hit < t < retract:
                lean += facing*(9*(1-recovery)-2*recovery)
        else:
            # no anticipatory flinch; response begins only after the contact instant.
            q=clamp((t-hit-.025)/.22)
            recoil=max(recoil, smooth(q)*math.exp(-max(0,t-hit-.025)*2.8))
    x += (-10*recoil if side==0 else 10*recoil)
    lean += (-15*recoil if side==0 else 15*recoil)
    crouch += 4*recoil
    return dict(x=x,lean=lean,crouch=crouch,bob=bob,recoil=recoil,facing=facing)

def body_points(s):
    x=s['x']; f=s['facing']; lean=s['lean']; c=s['crouch']; bob=s['bob']
    hip=(x+lean*.22,GROUND-88+c)
    shoulder=(x+lean,GROUND-142+c*.58+bob)
    head=(shoulder[0]+f*1.5,shoulder[1]-16)
    # planted feet: world-space points remain fixed while the stance is stable;
    # the short authored approach is the only translation phase.
    phase=clamp((x-(436 if f==1 else 524))/1) # stance phase placeholder
    feet=((x-f*17,GROUND),(x+f*18,GROUND))
    return hip,shoulder,head,feet

def active_strike(t,side):
    chosen=None
    for e in EVENTS:
        tm,att,kind,wind,hit,retract,away=e
        if att!=side: continue
        if wind-.12 <= t <= retract+.08:
            chosen=e
    return chosen

def draw_limb(d,pts,width=6):
    pts=[(round(x),round(y)) for x,y in pts]
    d.line(pts,fill=INK,width=width,joint='curve')
    r=max(2,width//2)
    for x,y in pts[1:-1]:
        d.ellipse((x-r,y-r,x+r,y+r),fill=INK)

def draw_character(img,s,side,t,other_state):
    d=ImageDraw.Draw(img); f=s['facing']
    hip,shoulder,head,feet=body_points(s)
    # elbows/wrists use two-bone IK, not independent decorative line poses.
    # Neutral guard: lead hand protects the cheek line; rear hand stays near upper chest.
    # Wrists are deliberately not placed above the head, and elbow bend points downward.
    guard_lead=(shoulder[0]+f*27,shoulder[1]-11)
    guard_rear=(shoulder[0]+f*12,shoulder[1]+8)
    strike=active_strike(t,side)
    lead=guard_lead; rear=guard_rear
    if strike:
        tm,att,kind,wind,hit,retract,away=strike
        defender=body_points(other_state)
        dhip,dshoulder,dhead,dfeet=defender
        if kind=='head':
            # aim at the near side of the head, not the space between the fighters.
            target=(dhead[0]-f*8,dhead[1]+4)
        else:
            target=(dshoulder[0]-f*7,dshoulder[1]+29)
        # Aim trajectory is smoothly drawn to the target. At the impact frame wrist == target.
        if t < wind:
            phase=0
        elif t <= hit:
            phase=smooth((t-wind)/(hit-wind))
        elif t <= retract:
            phase=1-smooth((t-hit)/(retract-hit))
        else: phase=0
        # ensure target is physically reachable: stance spacing is designed for this range.
        wrist=(mix(guard_lead[0],target[0],phase),mix(guard_lead[1],target[1],phase))
        if abs(t-hit)<1/FPS*.45:
            wrist=target
        lead=wrist
    # 46+46 px matches the full arm reach to target spacing.
    # Bend sign is toward the floor; the old sign flipped elbows above the shoulders.
    if strike and dist(lead,guard_lead)>1.0:
        e1=ik2(shoulder,lead,46,46,bend=f)
    else:
        e1=(shoulder[0]+f*13,shoulder[1]+17)
    e2=(shoulder[0]+f*6,shoulder[1]+20)
    # Knees bend in opposite directions to create a stable, readable combat stance.
    k1=ik2(hip,feet[0],48,48,bend=f)
    k2=ik2(hip,feet[1],48,48,bend=-f)
    # far leg/arm, torso, near leg/arm layering
    draw_limb(d,[hip,k1,feet[0]],6)
    draw_limb(d,[hip,shoulder],7)
    draw_limb(d,[shoulder,e2,rear],6)
    draw_limb(d,[hip,k2,feet[1]],6)
    draw_limb(d,[shoulder,e1,lead],6)
    rr=9
    d.ellipse((head[0]-rr,head[1]-rr,head[0]+rr,head[1]+rr),outline=INK,width=6)
    for wrist in (lead,rear):
        d.ellipse((wrist[0]-3,wrist[1]-3,wrist[0]+3,wrist[1]+3),fill=INK)
    for foot in feet:
        draw_limb(d,[foot,(foot[0]+f*11,foot[1])],5)
    return {'hip':hip,'shoulder':shoulder,'head':head,'lead':lead,'target':target if strike else None}

def render_frame(index,width=W,height=H):
    t=index/FPS
    img=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(img)
    d.line((0,GROUND+3,W,GROUND+3),fill=(20,20,20),width=2)
    a=fighter_state(t,0); b=fighter_state(t,1)
    # Contact poses are solved against the defender's pre-reaction body position.
    # The hit tick is only drawn if the attacker's wrist is at the target surface.
    ca=draw_character(img,a,0,t,b)
    cb=draw_character(img,b,1,t,a)
    hit=None
    for e in EVENTS:
        tm,att,kind,wind,contact,retract,away=e
        if abs(t-contact)<=0.51/FPS:
            attacker=ca if att==0 else cb
            defender=cb if att==0 else ca
            if attacker['target'] and dist(attacker['lead'],attacker['target']) < 1.5:
                hit=(attacker['target'][0],attacker['target'][1])
    if hit:
        cx,cy=hit
        # restrained impact mark exactly at the verified contact point, after contact
        d.ellipse((cx-7,cy-7,cx+7,cy+7),outline=(25,25,25),width=2)
        d.line((cx-11,cy,cx-7,cy),fill=(25,25,25),width=2)
        d.line((cx+7,cy,cx+11,cy),fill=(25,25,25),width=2)
        d.line((cx,cy-11,cx,cy-7),fill=(25,25,25),width=2)
        d.line((cx,cy+7,cx,cy+11),fill=(25,25,25),width=2)
    if (width,height)!=(W,H): img=img.resize((width,height),Image.Resampling.LANCZOS)
    return img

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--frames-dir',default='animated/scene-01')
    ap.add_argument('--output',default='output/stickman-battle-scene-01.mp4')
    ap.add_argument('--fps',type=int,default=FPS); ap.add_argument('--duration',type=float,default=DURATION)
    ap.add_argument('--width',type=int,default=W); ap.add_argument('--height',type=int,default=H)
    ap.add_argument('--frames-only',action='store_true'); ap.add_argument('--limit-frames',type=int,default=0)
    args=ap.parse_args()
    if min(args.fps,args.width,args.height)<=0 or args.duration<=0: ap.error('positive fps, dimensions and duration required')
    root=Path(__file__).resolve().parents[1]
    frame_dir=root/args.frames_dir; frame_dir.mkdir(parents=True,exist_ok=True)
    count=int(round(args.fps*args.duration)); count=min(count,args.limit_frames) if args.limit_frames else count
    for i in range(count):
        render_frame(i,args.width,args.height).save(frame_dir/f'frame_{i:06d}.png',compress_level=2)
        if (i+1)%120==0 or i+1==count: print(f'frames: {i+1}/{count}')
    if args.frames_only: return
    ffmpeg=shutil.which('ffmpeg')
    if not ffmpeg: raise SystemExit('ffmpeg unavailable; frames rendered but not encoded')
    out=root/args.output; out.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run([ffmpeg,'-y','-loglevel','error','-framerate',str(args.fps),' -i'.strip(),'x'],check=False) if False else None
    subprocess.run([ffmpeg,'-y','-loglevel','error','-framerate',str(args.fps),'-i',str(frame_dir/'frame_%06d.png'),'-frames:v',str(count),'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
    print(f'video: {out} ({count} frames, {args.fps} fps, {count/args.fps:.2f}s)')
if __name__=='__main__': main()
