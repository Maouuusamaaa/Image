import importlib.util
import unittest
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("render_battle",ROOT/"scripts"/"render_battle.py")
rb=importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)

class ContactTests(unittest.TestCase):
    def test_each_strike_has_reachable_contact_target(self):
        self.assertEqual(len(rb.EVENTS),11)
        for _,att,kind,wind,hit,retract,_ in rb.EVENTS:
            a=rb.fighter_state(hit,0); b=rb.fighter_state(hit,1)
            image=Image.new("RGB",(rb.W,rb.H),"white")
            ca=rb.draw_character(image,a,0,hit,b)
            cb=rb.draw_character(image,b,1,hit,a)
            actor=ca if att==0 else cb
            self.assertLess(rb.dist(actor["lead"],actor["target"]),0.01)
            self.assertLessEqual(rb.dist(actor["shoulder"],actor["target"]),92.0)
            self.assertLess(wind,hit)
            self.assertLess(hit,retract)

    def test_reaction_does_not_start_before_impact(self):
        for _,att,kind,wind,hit,retract,_ in rb.EVENTS:
            defender=1-att
            before=rb.fighter_state(hit-0.04,defender)
            at=rb.fighter_state(hit,defender)
            self.assertLess(before["recoil"],0.01)
            self.assertLess(at["recoil"],0.01)

    def test_video_render_dimensions_and_duration(self):
        video=ROOT/"output"/"stickman-battle-scene-01.mp4"
        self.assertTrue(video.exists())
        self.assertGreater(video.stat().st_size,10000)

if __name__=="__main__": unittest.main()
